// --- CONFIGURATION ---
const SERVER_URL = "https://myenglishlab.blog/api"; 

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const loginSection = document.getElementById('loginSection');
    const mainSection = document.getElementById('mainSection');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const solveBtn = document.getElementById('solveBtn');
    const creditDisplay = document.getElementById('creditDisplay');
    const modelNameInput = document.getElementById('modelName');
    const statusDiv = document.getElementById('status');
    
    // Controls
    const autoSkipCheckbox = document.getElementById('autoSkipVideos');
    const fullAutoBtn = document.getElementById('fullAutoBtn');

    // Load Saved State
    chrome.storage.sync.get(['authToken', 'credits', 'savedModel', 'autoSkipVideos', 'fullAutoMode'], (data) => {
        if (data.authToken) {
            showMainInterface(data.credits);
        } else {
            showLoginInterface();
        }
        
        if (data.savedModel) {
            modelNameInput.value = data.savedModel;
            // Ensure valid selection
            if (!modelNameInput.value) modelNameInput.selectedIndex = 0;
        }

        // Restore States
        if (data.autoSkipVideos) autoSkipCheckbox.checked = true;
        
        // Update Button State
        updateFullAutoButton(!!data.fullAutoMode);
    });

    // --- FULL AUTO BUTTON HANDLER ---
    fullAutoBtn.addEventListener('click', () => {
        chrome.storage.sync.get(['fullAutoMode'], (data) => {
            const currentState = !!data.fullAutoMode;
            const newState = !currentState;
            
            // 1. Update UI
            updateFullAutoButton(newState);

            // 2. Save State
            chrome.storage.sync.set({ fullAutoMode: newState });

            // 3. Handle Side Effects (Auto Skip)
            if (newState) {
                // Force skip on for Full Auto
                autoSkipCheckbox.checked = true;
                autoSkipCheckbox.disabled = true;
                chrome.storage.sync.set({ autoSkipVideos: true });
            } else {
                autoSkipCheckbox.disabled = false;
            }

            // 4. Notify Content Script
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { 
                        action: "update_auto_solve", 
                        enabled: newState 
                    });
                }
            });
        });
    });

    function updateFullAutoButton(isOn) {
        if (isOn) {
            fullAutoBtn.textContent = "Durdur 🛑";
            fullAutoBtn.className = "danger"; // Use danger class for stop
        } else {
            fullAutoBtn.textContent = "Başlat 🚀";
            fullAutoBtn.className = "primary"; // Use primary class for start
        }
    }

    // --- AUTO SKIP TOGGLE ---
    autoSkipCheckbox.addEventListener('change', () => {
        const isChecked = autoSkipCheckbox.checked;
        chrome.storage.sync.set({ autoSkipVideos: isChecked });
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { 
                    action: "update_skip_setting", 
                    enabled: isChecked 
                });
            }
        });
    });

    // --- LOGIN HANDLER ---
    loginBtn.addEventListener('click', async () => {
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        if (!username || !password) {
            showStatus('Please enter username and password', 'error');
            return;
        }

        showStatus('Logging in...', 'loading');

        try {
            const response = await fetch(`${SERVER_URL}/login.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (data.success) {
                chrome.storage.sync.set({
                    authToken: data.token,
                    credits: data.requests_left,
                    username: data.username
                });
                showMainInterface(data.requests_left);
                showStatus('Login successful!', 'success');
            } else {
                showStatus(data.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error(error);
            showStatus('Connection error. Check server URL.', 'error');
        }
    });

    // --- LOGOUT HANDLER ---
    logoutBtn.addEventListener('click', () => {
        chrome.storage.sync.remove(['authToken', 'credits']);
        showLoginInterface();
        showStatus('Logged out.', 'success');
    });

    // --- SOLVE HANDLER (Manual) ---
    solveBtn.addEventListener('click', async () => {
        const storage = await chrome.storage.sync.get(['authToken', 'credits']);
        const token = storage.authToken;
        const model = modelNameInput.value.trim();

        if (!token) {
            showStatus('Session expired. Please login again.', 'error');
            showLoginInterface();
            return;
        }

        chrome.storage.sync.set({ savedModel: model });
        showStatus('Analyzing page...', 'loading');

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return;

        try {
            const extraction = await sendMessagePromise(tab.id, { action: "extract_questions" });
            
            if (!extraction || !extraction.success) {
                showStatus(extraction?.error || 'No questions found.', 'error');
                return;
            }

            showStatus('Requesting server...', 'loading');

            chrome.runtime.sendMessage({
                action: "solve_securely",
                payload: extraction.data,
                token: token,
                model: model,
                serverUrl: SERVER_URL
            }, (response) => {
                if (chrome.runtime.lastError) {
                    showStatus('Runtime Error: ' + chrome.runtime.lastError.message, 'error');
                    return;
                }

                if (response && response.success) {
                    const newCredits = response.creditsLeft;
                    updateCreditDisplay(newCredits);
                    chrome.storage.sync.set({ credits: newCredits });

                    showStatus('Applying answers...', 'loading');

                    chrome.tabs.sendMessage(tab.id, {
                        action: "apply_answers",
                        answers: response.answers
                    }, (applyRes) => {
                        if (applyRes && applyRes.success) {
                            showStatus('Done!', 'success');
                        } else {
                            showStatus('Failed to write answers.', 'error');
                        }
                    });

                } else {
                    showStatus(response?.error || 'Server rejected request.', 'error');
                }
            });

        } catch (e) {
            console.error(e);
            showStatus('Error: Refresh page.', 'error');
        }
    });

    function sendMessagePromise(tabId, message) {
        return new Promise((resolve, reject) => {
            chrome.tabs.sendMessage(tabId, message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(response);
                }
            });
        });
    }

    function showLoginInterface() {
        loginSection.classList.remove('hidden');
        mainSection.classList.add('hidden');
        usernameInput.value = '';
        passwordInput.value = '';
    }

    function showMainInterface(credits) {
        loginSection.classList.add('hidden');
        mainSection.classList.remove('hidden');
        updateCreditDisplay(credits);
    }

    function updateCreditDisplay(val) {
        creditDisplay.textContent = val;
        if (val <= 0) {
            creditDisplay.style.color = 'red';
            solveBtn.disabled = true;
            solveBtn.innerText = "No Credits";
        } else {
            creditDisplay.style.color = '#333';
            solveBtn.disabled = false;
        }
    }

    function showStatus(msg, type) {
        statusDiv.textContent = msg;
        statusDiv.className = 'status ' + type;
    }
});