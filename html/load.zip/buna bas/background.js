chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Handle the secure solve request from Popup
    if (request.action === "solve_securely") {
        handleSecureSolve(request)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({ success: false, error: error.message }));
        
        return true; // Indicates asynchronous response
    }
});

/**
 * Orchestrates the secure solving process:
 * 1. Calls PHP Server with User Token to check credits and get a temp API Key.
 * 2. Uses that key to call Gemini.
 * 3. Returns answers + remaining credits.
 */
async function handleSecureSolve(data) {
    const { payload, token, model, serverUrl } = data;

    if (!token || !serverUrl) {
        throw new Error("Configuration Error: Missing Token or Server URL");
    }

    // --- STEP 1: Get Key from PHP Server ---
    // This call will decrement 1 credit on the server side immediately.
    let authResponse;
    try {
        authResponse = await fetch(`${serverUrl}/solve.php`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            // We don't need a body, the Bearer token identifies the user
            body: JSON.stringify({}) 
        });
    } catch (networkError) {
        throw new Error("Failed to contact server. Check internet or server URL.");
    }

    if (!authResponse.ok) {
        // Try to parse error message from server
        let errorMsg = `Server Error: ${authResponse.status}`;
        try {
            const errData = await authResponse.json();
            if (errData.error) errorMsg = errData.error;
        } catch(e) {}
        throw new Error(errorMsg);
    }

    const authData = await authResponse.json();

    if (!authData.success || !authData.api_key) {
        throw new Error(authData.error || "Server approved request but returned no API key.");
    }

    const tempApiKey = authData.api_key;
    const creditsLeft = authData.requests_left;

    // --- STEP 2: Call Gemini API ---
    // Now we use the key we just "bought" with a credit
    try {
        const answers = await solveWithGemini(payload, tempApiKey, model);
        return { 
            success: true, 
            answers: answers, 
            creditsLeft: creditsLeft 
        };
    } catch (geminiError) {
        // Note: The credit is already spent on the server.
        throw new Error(`Gemini Error: ${geminiError.message}`);
    }
}

/**
 * Calls Google Gemini API
 */
async function solveWithGemini(payload, apiKey, modelName) {
    const { text, blanks } = payload;
    // Use the model passed from UI, or fallback
    const model = modelName || 'gemini-2.0-flash-exp';

    const prompt = `
    You are an expert English language tutor.
    
    TASK: Fill in the blanks based on the text context and grammatical rules.
    
    INPUT TEXT:
    """
    ${text}
    """

    BLANKS TO SOLVE (JSON):
    ${JSON.stringify(blanks)}

    SPECIFIC INSTRUCTIONS:
    1. If a blank object has an 'options' list (e.g., ["T", "I"]), your answer MUST be exactly one of those options.
    2. For 'text_single_char' types with options ["T", "I"], you must determine if the verb is used Transitively (T) or Intransitively (I) in the context. Output ONLY "T" or "I".
    3. Return strictly a valid JSON object.
    4. Format: {"ID": "ANSWER", "ID2": "ANSWER"}
    5. Do NOT use Markdown code blocks (no \`\`\`json).
    6. Escape all quotes and backslashes within strings properly.

    JSON OUTPUT:
    `;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }]
        })
    });

    if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error?.message || `Gemini API Status: ${response.status}`);
    }

    const data = await response.json();

    if (!data.candidates || data.candidates.length === 0) {
        throw new Error("Gemini returned no candidates.");
    }

    let rawText = data.candidates[0].content.parts[0].text;

    // Cleanup Markdown if Gemini ignores instructions
    rawText = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
    const jsonStartIndex = rawText.indexOf('{');
    const jsonEndIndex = rawText.lastIndexOf('}');

    if (jsonStartIndex !== -1 && jsonEndIndex !== -1) {
        rawText = rawText.substring(jsonStartIndex, jsonEndIndex + 1);
    }

    try {
        return JSON.parse(rawText);
    } catch (firstError) {
        console.warn("First JSON parse failed, attempting repair...", firstError);
        // Try to fix common newline issues
        const fixedText = rawText.replace(/(?<!\\)\n/g, "\\n").replace(/\r/g, "");
        try {
            return JSON.parse(fixedText);
        } catch (secondError) {
            throw new Error("Failed to parse Gemini response as JSON.");
        }
    }
}