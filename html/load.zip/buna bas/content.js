// --- CONFIGURATION ---
const SERVER_URL = "https://myenglishlab.blog/api"; 

// Global State
let autoSkipEnabled = false;
let fullAutoEnabled = false;
let skipCheckInterval = null;
let autoSolveLoopActive = false;
let watchdogInterval = null;
let lastSkippedUrl = ""; // Track last skipped URL to prevent looping

// --- INITIALIZATION ---
chrome.storage.sync.get(['autoSkipVideos', 'fullAutoMode'], (data) => {
    autoSkipEnabled = !!data.autoSkipVideos;
    fullAutoEnabled = !!data.fullAutoMode;

    if (autoSkipEnabled) {
        startSkipCheck();
    }
    
    // Start the watchdog immediately.
    startWatchdog();
});

// --- MESSAGE LISTENER ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extract_questions") {
    try {
      const data = extractContextAndBlanks();
      if (data && (data.blanks.length > 0 || data.text.length > 50)) {
        sendResponse({ success: true, data: data });
      } else {
        // Silent failure
      }
    } catch (e) {
      console.error(e);
      if (e.message !== "No visible questions detected") {
          sendResponse({ success: false, error: e.message });
      }
    }
    return true; 
  } 
  
  else if (request.action === "apply_answers") {
    // Made async to support keyboard simulation delays
    (async () => {
        try {
            const count = await applyAnswers(request.answers);
            if (count >= 0) {
                sendResponse({ success: true, count: count });
            }
        } catch (e) {
            console.error(e);
            sendResponse({ success: false, error: e.message });
        }
    })();
    return true;
  }

  else if (request.action === "update_skip_setting") {
      autoSkipEnabled = request.enabled;
      if (autoSkipEnabled) startSkipCheck();
      else stopSkipCheck();
  }

  else if (request.action === "update_auto_solve") {
      fullAutoEnabled = request.enabled;
      if (fullAutoEnabled) {
          showNotification("🚀 Full Auto Mode Started", "#007bff");
          if (!autoSolveLoopActive) startAutoSolveEngine();
      } else {
          showNotification("🛑 Full Auto Mode Stopped", "#dc3545");
          autoSolveLoopActive = false; 
      }
  }
});


// ==========================================
//      🚀 FULL AUTO AUTOMATION ENGINE
// ==========================================

function startWatchdog() {
    if (watchdogInterval) clearInterval(watchdogInterval);
    watchdogInterval = setInterval(() => {
        if (fullAutoEnabled && !autoSolveLoopActive) {
            console.log("Pearson Solver: Watchdog restarting engine...");
            startAutoSolveEngine();
        }
    }, 2000);
}

async function startAutoSolveEngine() {
    if (autoSolveLoopActive) return; 
    autoSolveLoopActive = true;
    
    console.log("Pearson Solver: Engine Started");
    let isFirstRun = true;

    try {
        while (fullAutoEnabled && autoSolveLoopActive) {
            try {
                const currentUrl = window.location.href;

                if (!isFirstRun) {
                    await new Promise(r => setTimeout(r, 1000)); 
                }
                isFirstRun = false;

                // --- STEP 0: POPUP HANDLING (RETRY MECHANISM) ---
                // If "Unanswered questions" popup appears, Cancel it to retry solving.
                if (checkAndHandlePopup()) {
                    showNotification("⚠️ Retrying unanswered...", "#ffc107");
                    await new Promise(r => setTimeout(r, 1500)); // Wait for modal to close
                    // Loop continues, which hits STEP 2 (Solve Phase) again
                }

                // --- STEP 1: PRE-CHECK ---
                const isReportPage = window.location.href.includes('/report') || 
                                     window.location.href.includes('/summary') ||
                                     document.title.includes('Report') || 
                                     document.title.includes('Özet');

                // --- STEP 2: SOLVE PHASE ---
                let data = null;
                if (document.readyState === 'complete' && !isReportPage) {
                    data = extractContextAndBlanks();
                } else if (isReportPage) {
                    console.log("Pearson Solver: Report page detected. Skipping solve phase.");
                }

                if (data && data.blanks.length > 0) {
                    showNotification("🤖 Solving...", "#17a2b8");
                    const credentials = await getCredentials();
                    
                    if (!credentials || !credentials.token) {
                        showNotification("❌ Login required", "#dc3545");
                        fullAutoEnabled = false; 
                        chrome.storage.sync.set({ fullAutoMode: false });
                        return;
                    }

                    const response = await sendMessagePromise({
                        action: "solve_securely",
                        payload: data,
                        token: credentials.token,
                        model: credentials.model,
                        serverUrl: SERVER_URL
                    });

                    if (response && response.success) {
                        await applyAnswers(response.answers);
                        await new Promise(r => setTimeout(r, 2000)); 
                    } else {
                        showNotification("❌ API Error: " + (response?.error || "Unknown"), "#dc3545");
                        fullAutoEnabled = false;
                        chrome.storage.sync.set({ fullAutoMode: false });
                        return;
                    }
                }

                // --- STEP 3: NAVIGATION PHASE ---
                
                // Priority A: Click "Next"
                const movedNext = attemptClickNext();
                if (movedNext) {
                    showNotification("➡️ Moving Next...", "#28a745");
                    lastSkippedUrl = ""; 
                    await waitForNextPage(currentUrl); 
                    continue; 
                }

                // Priority B: Click "Submit"
                const submitted = attemptClickSubmit();
                if (submitted) {
                    showNotification("✅ Submitting...", "#28a745");
                    await new Promise(r => setTimeout(r, 6000));
                    
                    if (attemptClickNext()) {
                        showNotification("➡️ Moving Next...", "#28a745");
                        lastSkippedUrl = "";
                        await waitForNextPage(window.location.href);
                    }
                    continue; 
                }

                if (fullAutoEnabled) {
                    await new Promise(r => setTimeout(r, 2000)); 
                }

            } catch (err) {
                console.error("Auto Engine Error (Inner):", err);
                await new Promise(r => setTimeout(r, 3000));
            }
        }
    } catch (err) {
        console.error("Auto Engine Fatal Error:", err);
    } finally {
        autoSolveLoopActive = false;
        console.log("Pearson Solver: Engine Stopped");
    }
}

// --- NEW FUNCTION: Detect and dismiss "Unanswered Questions" popup ---
function checkAndHandlePopup() {
    const dialog = document.querySelector('.ui-dialog[aria-labelledby="ui-dialog-title-messageDialog"]');
    
    // Check if dialog exists and is visible
    if (dialog && dialog.style.display !== 'none' && dialog.offsetParent !== null) {
        // Look for the "Cancel" (İptal) button specifically
        const cancelBtn = dialog.querySelector('#cancel');
        if (cancelBtn) {
            console.log("Pearson Solver: Unanswered Questions Popup detected. Clicking Cancel to retry.");
            cancelBtn.click();
            return true;
        }
    }
    return false;
}

async function waitForNextPage(oldUrl) {
    let checks = 0;
    const maxChecks = 60; // 30 seconds max
    
    // 1. Wait for URL change
    while (checks < maxChecks) {
        if (window.location.href !== oldUrl) break; 
        await new Promise(r => setTimeout(r, 500));
        checks++;
    }

    // 2. Wait for DOM Ready
    checks = 0;
    while (checks < maxChecks) {
        if (document.readyState === 'complete') {
            await new Promise(r => setTimeout(r, 1000)); 
            return;
        }
        await new Promise(r => setTimeout(r, 500));
        checks++;
    }
}

function attemptClickSubmit() {
    // Don't click submit if a blocking popup is already visible
    if (document.querySelector('.ui-dialog[aria-labelledby="ui-dialog-title-messageDialog"][style*="display: block"]')) {
        return false;
    }

    const idBtn = document.getElementById('submitButton');
    if (idBtn && isClickable(idBtn)) {
        idBtn.click();
        return true;
    }

    const keywords = ['gönder', 'submit', 'finish', 'bitir', 'complete'];
    const buttons = Array.from(document.querySelectorAll('button, a.button, input[type="button"], input[type="submit"], div[role="button"]'));
    
    const textBtn = buttons.find(btn => {
        if (!isClickable(btn)) return false;
        const text = (btn.innerText || btn.value || "").trim().toLowerCase();
        return keywords.includes(text);
    });

    if (textBtn) {
        textBtn.click();
        return true;
    }
    return false;
}

function attemptClickNext() {
    const isPreviousButton = (el) => {
        return el.classList.contains('previous') || el.classList.contains('prev');
    };

    const idIds = ['next', 'nextActivity', 'next-activity-link', 'link-next'];
    for (const id of idIds) {
        const btn = document.getElementById(id);
        if (btn && isClickable(btn) && !isPreviousButton(btn)) {
            btn.click();
            return true;
        }
    }

    const selectors = [
        'a.next', 'li.next a', '.next-activity', '.nav-next',
        '.pagination-next', '[aria-label="Next"]', '[aria-label="Sonraki"]',
        '[aria-label^="Go to page"]', '[aria-label^="Sayfaya git"]',
        'nav[role="navigation"] a[aria-label^="Go to"]', 
        '[title="Next"]', '[title="Sonraki"]', '.footer-next-btn'
    ];

    for (const sel of selectors) {
        const btn = document.querySelector(sel);
        if (btn && isClickable(btn) && !isPreviousButton(btn)) {
            btn.click();
            return true;
        }
    }

    const keywords = ['sonraki', 'next', 'forward', 'devam', 'go to page', 'sayfaya git'];
    const candidates = Array.from(document.querySelectorAll('a, button, div[role="button"], span, input[type="button"], input[type="submit"]'));

    const textTarget = candidates.find(b => {
        if (!isClickable(b)) return false;
        if (isPreviousButton(b)) return false;
        
        const text = (b.innerText || b.value || "").trim().toLowerCase();
        const ariaLabel = (b.getAttribute('aria-label') || "").toLowerCase();
        
        if (text === '>' || text === '»' || text === '→') return true;
        return keywords.some(k => text.includes(k) || ariaLabel.includes(k));
    });

    if (textTarget) {
        textTarget.click();
        return true;
    }
    return false;
}

function isClickable(el) {
    if (!el) return false;
    if (el.offsetParent === null) return false; 
    if (el.disabled) return false;
    if (el.getAttribute('aria-disabled') === 'true') return false;
    if (el.classList.contains('disabled')) return false;
    if (el.classList.contains('almost-hidden')) return false; 
    return true;
}

function getCredentials() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['authToken', 'savedModel'], (items) => {
            resolve({
                token: items.authToken,
                model: items.savedModel || 'gemini-2.0-flash-exp'
            });
        });
    });
}

function sendMessagePromise(msg) {
    return new Promise((resolve) => {
        chrome.runtime.sendMessage(msg, (response) => {
            if (chrome.runtime.lastError) {
                resolve({ success: false, error: chrome.runtime.lastError.message });
            } else {
                resolve(response);
            }
        });
    });
}

function showNotification(text, color) {
    let notif = document.getElementById('pearson-auto-notif');
    if (!notif) {
        notif = document.createElement('div');
        notif.id = 'pearson-auto-notif';
        notif.style.cssText = `
            position: fixed; top: 20px; right: 20px; padding: 10px 20px;
            color: white; border-radius: 8px; font-family: sans-serif;
            font-weight: bold; font-size: 14px; z-index: 999999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2); transition: all 0.3s;
        `;
        document.body.appendChild(notif);
    }
    notif.style.backgroundColor = color || '#333';
    notif.innerText = text;
    notif.style.opacity = '1';
    setTimeout(() => { notif.style.opacity = '0'; }, 3000);
}


// ==========================================
//      AUTO SKIPPER
// ==========================================

function startSkipCheck() {
    attemptVideoSkip();
    if (skipCheckInterval) clearInterval(skipCheckInterval);
    skipCheckInterval = setInterval(attemptVideoSkip, 500);
}

function stopSkipCheck() {
    if (skipCheckInterval) {
        clearInterval(skipCheckInterval);
        skipCheckInterval = null;
    }
}

function attemptVideoSkip() {
    if (!autoSkipEnabled) return;
    if (document.readyState !== 'complete') return;
    if (window.location.href === lastSkippedUrl) return;

    const hasVideo = document.querySelector('video') || document.querySelector('.mejs-video');
    if (hasVideo) {
        if (hasVideo.offsetParent === null) return;
        const clicked = attemptClickNext();
        if (clicked) {
            console.log("Pearson Solver: Video detected. Skipping...");
            lastSkippedUrl = window.location.href; 
        }
    }
}

function extractContextAndBlanks() {
  const candidates = document.querySelectorAll('.taskContent, .reading-frame, .activity-container, .task');
  let container = null;

  for (const cand of candidates) {
      if (cand.offsetParent === null) continue;
      const hiddenParent = cand.closest('.almost-hidden, .hidden, .is-hidden');
      if (hiddenParent) continue;
      
      if(cand.innerText.trim().length > 0) {
          container = cand;
          break; 
      }
  }

  if (!container) return null;

  let instructionText = "";
  const taskWrapper = container.closest('.task') || container;
  if (taskWrapper) {
      const rubric = taskWrapper.querySelector('.taskRubric');
      if (rubric) instructionText = "INSTRUCTIONS:\n" + rubric.innerText.trim() + "\n\n";
  }

  const clone = container.cloneNode(true);
  const blanks = [];

  // --- TYPE 1: Select/Dropdowns ---
  const selects = clone.querySelectorAll('select.activity-select, select');
  selects.forEach(select => {
    if (select.style.display === 'none' || select.type === 'hidden' || select.disabled) return;
    const id = select.id;
    const originalSelect = document.getElementById(id);
    if (!originalSelect || originalSelect.disabled) return;

    const options = Array.from(originalSelect.options).filter(opt => opt.value !== "").map(opt => opt.textContent.trim());
    if (options.length > 0) {
      blanks.push({ id: id, type: 'select', options: options });
      select.parentNode.replaceChild(document.createTextNode(` [[${id}]] `), select);
    }
  });

  // --- TYPE 2: Clickable Groups (Underline) ---
  const underlineGroups = clone.querySelectorAll('.underlineGroup');
  underlineGroups.forEach(group => {
    if(group.classList.contains('disabled')) return; 
    const id = group.id;
    const originalGroup = document.getElementById(id);
    if (!originalGroup) return;
    const options = Array.from(originalGroup.querySelectorAll('.underlineElement')).map(span => span.innerText.trim());
    if (options.length > 0) {
      blanks.push({ id: id, type: 'click', options: options });
      group.parentNode.replaceChild(document.createTextNode(` [[${id}]] `), group);
    }
  });

  // --- TYPE 3: Jumbled Sentence ---
  const jumbledItems = clone.querySelectorAll('.draggableJumbledWords');
  jumbledItems.forEach(item => {
      const dropZone = item.querySelector('.droppableWrapper');
      if (!dropZone) return;
      const id = dropZone.id;
      if(dropZone.classList.contains('ui-droppable-disabled')) return;

      const wordPool = item.querySelector('.wordpoolWrapper');
      const poolDrags = Array.from(wordPool.querySelectorAll('.drag'));
      const targetDrags = Array.from(dropZone.querySelectorAll('.drag'));
      const allDrags = [...poolDrags, ...targetDrags];
      
      const options = allDrags.map(d => d.innerText.trim());
      if (options.length > 0) {
          blanks.push({ id: id, type: 'jumbled_sentence', options: options });
          const fragmentsHint = `\n[Use these exact fragments: ${JSON.stringify(options)}]`;
          const placeholder = document.createTextNode(` [[${id}]] ${fragmentsHint} `);
          item.parentNode.replaceChild(placeholder, item);
      }
  });

  // --- TYPE 3.5: Hangman / Single Char (T/I Questions) ---
  // CORRECTION: Targeting the SPAN class, then finding the input inside.
  // The ID is on the SPAN, not the input.
  const hangmanSpans = clone.querySelectorAll('.hangmanGroup');
  hangmanSpans.forEach(span => {
    const id = span.id; // The unique ID is on the span
    const input = span.querySelector('input[type="text"]');
    if (!id || !input || input.disabled || input.type === 'hidden') return;
    
    // We explicitly tell Gemini that the options are T or I.
    blanks.push({ 
        id: id, 
        type: 'text_single_char', 
        options: ['T', 'I'], 
        hint: "Transitive (T) or Intransitive (I)" 
    });

    // Replace the span wrapper with the placeholder so it's not detected as a generic input later
    const placeholder = document.createTextNode(` [[${id}]] `);
    span.parentNode.replaceChild(placeholder, span);
  });

  // --- TYPE 4: Text Inputs ---
  const inputs = clone.querySelectorAll('input[type="text"], textarea');
  inputs.forEach(input => {
    const id = input.id;
    if (!id || input.type === 'hidden' || input.disabled || input.readOnly || input.classList.contains('disabled')) return;
    
    // Only process if it hasn't been removed by Type 3.5 (Hangman) above
    if (input.parentNode) {
        blanks.push({ id: id, type: 'text', options: [] });
        input.parentNode.replaceChild(document.createTextNode(` [[${id}]] `), input);
    }
  });

  // --- TYPE 5: Radio Buttons ---
  const radios = Array.from(clone.querySelectorAll('input[type="radio"]'));
  const processedNames = new Set();
  radios.forEach(radio => {
      const name = radio.name;
      if (!name || processedNames.has(name) || radio.disabled) return;
      
      processedNames.add(name);
      const groupRadios = document.querySelectorAll(`input[type="radio"][name="${name}"]`);
      const options = [];
      let groupID = name;
      groupRadios.forEach(r => {
          const label = r.nextElementSibling?.textContent || r.parentElement.textContent || r.value;
          options.push(label.trim());
      });
      if(options.length > 0) {
          blanks.push({ id: groupID, type: 'radio', options: options });
          const placeholder = document.createTextNode(` [[${groupID}]] `);
          radio.parentNode.insertBefore(placeholder, radio);
      }
  });

  // --- TYPE 6: Generic Drag & Drop ---
  const dropZones = clone.querySelectorAll('.drop, .target, .drop-zone');
  if(dropZones.length > 0) {
      const draggables = Array.from(document.querySelectorAll('.drag, .source, .draggable')).map(d => d.innerText.trim()).filter(t => t);
      dropZones.forEach((zone, index) => {
          if(zone.closest('.draggableJumbledWords') || zone.classList.contains('ui-droppable-disabled')) return;
          let id = zone.id || `generated_gap_${index}`;
          blanks.push({ id: id, type: 'drag_drop', options: [...new Set(draggables)] });
          zone.parentNode.replaceChild(document.createTextNode(` [[${id}]] `), zone);
      });
  }

  const contentText = "CONTENT:\n" + clone.innerText.replace(/\s+/g, ' ').trim();
  const fullText = instructionText + contentText;
  return { text: fullText, blanks };
}

// ==========================================
//      APPLY ANSWERS (ASYNC UPDATED)
// ==========================================

async function applyAnswers(answers) {
  const existingPanel = document.getElementById('pearson-solver-panel');
  if (existingPanel) existingPanel.remove();

  const panel = document.createElement('div');
  panel.id = 'pearson-solver-panel';
  panel.style.cssText = `
    position: fixed; bottom: 20px; right: 20px; width: 320px; max-height: 500px;
    overflow-y: auto; background-color: #ffffff; border: 1px solid #e0e0e0;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2); z-index: 2147483647; border-radius: 12px;
    font-family: 'Segoe UI', sans-serif; display: flex; flex-direction: column;
    animation: slideIn 0.3s ease-out;
  `;

  const header = document.createElement('div');
  header.style.cssText = `
    background: #007bff; color: white; padding: 12px 15px; font-weight: bold;
    font-size: 14px; display: flex; justify-content: space-between; align-items: center;
    border-top-left-radius: 12px; border-top-right-radius: 12px;
  `;
  header.innerHTML = `<span>📝 Solutions (${Object.keys(answers).length})</span> <span style="cursor:pointer; font-size:18px;" onclick="this.parentElement.parentElement.remove()">×</span>`;
  panel.appendChild(header);

  const list = document.createElement('div');
  list.style.padding = '10px';
  list.style.background = '#f8f9fa';

  let questionIndex = 1;
  let count = 0;
  
  // Clean up previous "used" tags for this run
  document.querySelectorAll('.pearsons-bot-used').forEach(el => el.classList.remove('pearsons-bot-used'));

  // Pre-fetch all drag and drop targets if we need them for sequential tabbing
  const allDropZones = Array.from(document.querySelectorAll('.droppableWrapper, .drop, .target'));

  for (const [id, answerText] of Object.entries(answers)) {
    const cleanAnswer = answerText ? answerText.trim() : "";
    if (!cleanAnswer) continue;

    let applied = false;
    const element = document.getElementById(id);

    if (element) {
        if (element.tagName === 'SELECT') {
            const options = Array.from(element.options);
            let correctOption = options.find(opt => opt.textContent.trim() === cleanAnswer) || 
                                options.find(opt => opt.textContent.trim().toLowerCase() === cleanAnswer.toLowerCase());
            if (correctOption) {
                element.value = correctOption.value;
                dispatchEvents(element);
                element.style.border = "2px solid #28a745";
                applied = true;
            }
        } 
        else if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            element.value = cleanAnswer;
            dispatchEvents(element);
            element.style.border = "2px solid #28a745";
            applied = true;
        } 
        else if (element.classList.contains('underlineGroup')) {
            const spans = Array.from(element.querySelectorAll('.underlineElement'));
            const targetSpan = spans.find(s => s.innerText.trim() === cleanAnswer || s.innerText.trim().toLowerCase() === cleanAnswer.toLowerCase());
            if (targetSpan) {
                targetSpan.click();
                targetSpan.style.backgroundColor = "rgba(40, 167, 69, 0.2)";
                targetSpan.style.borderBottom = "2px solid #28a745";
                applied = true;
            }
        } 
        // --- NEW: Handle Hangman Group (T/I questions) ---
        // This was missing before! The ID is on the span, so element is the span.
        else if (element.classList.contains('hangmanGroup')) {
             const input = element.querySelector('input[type="text"]');
             if (input) {
                 input.value = cleanAnswer;
                 dispatchEvents(input);
                 input.style.border = "2px solid #28a745";
                 applied = true;
             }
        }
        // --- KEYBOARD-BASED DRAG & DROP LOGIC (TAB SYSTEM) ---
        else if (element.classList.contains('droppableWrapper') || element.classList.contains('drop') || element.classList.contains('target')) {
             
             // 1. Find the task container to scope our search
             const taskContainer = element.closest('.task') || document.body;
             
             // 2. Find the Word Pool
             const wordPool = taskContainer.querySelector('.wordpoolWrapper, .source-container');
             
             if (wordPool) {
                // 3. Find available source items
                const allSources = Array.from(wordPool.querySelectorAll('.drag, .ui-draggable, [draggable="true"]'));
                
                // 4. Find the correct source that hasn't been used yet
                let targetSource = allSources.find(src => {
                    const text = src.innerText.trim();
                    const textMatch = text === cleanAnswer;
                    const visible = src.style.display !== 'none' && src.style.visibility !== 'hidden';
                    const notUsed = !src.classList.contains('pearsons-bot-used');
                    return textMatch && visible && notUsed;
                });

                if (targetSource) {
                    // Mark as used to prevent duplicates
                    targetSource.classList.add('pearsons-bot-used');

                    try {
                        // 5. Simulate Tab/Enter Sequence
                        // Focus Source -> Select -> Focus Target -> Drop
                        
                        targetSource.focus();
                        targetSource.dispatchEvent(new MouseEvent('mousedown', {bubbles: true})); 
                        
                        triggerEnter(targetSource);
                        
                        await new Promise(r => setTimeout(r, 100)); 
                        
                        element.focus();
                        element.dispatchEvent(new MouseEvent('mousedown', {bubbles: true})); 
                        
                        triggerEnter(element);
                        
                        await new Promise(r => setTimeout(r, 150)); 

                        element.style.border = "2px solid #28a745";
                        applied = true;
                    } catch (err) {
                        console.error("Keyboard D&D Failed", err);
                    }
                } else {
                    console.warn(`Source not found for D&D: "${cleanAnswer}"`);
                }
             }
        } 
    }
    
    // Backup Radio Logic
    if (!applied) {
        const radios = document.querySelectorAll(`input[type="radio"][name="${id}"]`);
        for (const radio of radios) {
            const label = radio.nextElementSibling?.textContent?.trim() || radio.parentElement.textContent?.trim() || radio.value;
            if (label && label.toLowerCase().includes(cleanAnswer.toLowerCase())) {
                radio.click();
                if(radio.parentElement) radio.parentElement.style.borderBottom = "2px solid #28a745";
                applied = true;
                break;
            }
        }
    }

    const row = document.createElement('div');
    row.style.cssText = `
        padding: 8px; border-bottom: 1px solid #eee; display: flex; align-items: flex-start;
        background: white; margin-bottom: 5px; border-radius: 6px;
    `;
    row.innerHTML = `
        <span style="background:${applied ? '#28a745' : '#e9ecef'}; color:${applied?'#fff':'#495057'}; padding:2px 6px; border-radius:4px; margin-right:8px; font-weight:bold; font-size:12px; min-width:25px; text-align:center;">${questionIndex}</span>
        <span style="color:#212529; font-weight:500; font-size:13px; word-break:break-word;">${cleanAnswer}</span>
    `;
    list.appendChild(row);
    questionIndex++;
    if(applied) count++;
  }

  panel.appendChild(list);
  document.body.appendChild(panel);

  const style = document.createElement('style');
  style.innerHTML = `@keyframes slideIn { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`;
  document.head.appendChild(style);

  return count;
}

// --- HELPER FOR KEYBOARD SIMULATION ---
function triggerEnter(el) {
    const eventParams = {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true,
        view: window
    };
    el.dispatchEvent(new KeyboardEvent('keydown', eventParams));
    el.dispatchEvent(new KeyboardEvent('keypress', eventParams));
    el.dispatchEvent(new KeyboardEvent('keyup', eventParams));
}

function dispatchEvents(element) {
  element.dispatchEvent(new Event('change', { bubbles: true }));
  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('click', { bubbles: true }));
}